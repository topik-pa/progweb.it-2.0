import yfinance as yf
import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# 1. SCARICAMENTO DATI (5 anni di storico giornaliero)
print("Scaricamento dati da Yahoo Finance...")
titolo = yf.download("CPR.MI", period="5y", progress=False)
indice = yf.download("FTSEMIB.MI", period="5y", progress=False)

# Pulizia e allineamento immediato di tutte le colonne necessarie
df = pd.DataFrame()
df['Close'] = titolo['Close'].squeeze()
df['High'] = titolo['High'].squeeze()
df['Low'] = titolo['Low'].squeeze()
df['Volume'] = titolo['Volume'].squeeze()
df['MIB_Close'] = indice['Close'].squeeze()

df = df.dropna()

# 2. FEATURE ENGINEERING
# A. Performance passate (Momentum)
df['Perf_5gg'] = df['Close'].pct_change(5)
df['Perf_21gg'] = df['Close'].pct_change(21)
df['Perf_144gg'] = df['Close'].pct_change(144)

# B. Trend attuale (Distanza percentuale dalle medie mobili)
sma_21 = df['Close'].rolling(21).mean()
sma_55 = df['Close'].rolling(55).mean()
sma_233 = df['Close'].rolling(233).mean()

df['Dist_SMA21'] = (df['Close'] - sma_21) / sma_21
df['Dist_SMA55'] = (df['Close'] - sma_55) / sma_55
df['Dist_SMA233'] = (df['Close'] - sma_233) / sma_233

# C. Volatilità (Deviazione standard dei rendimenti a 21gg)
df['Volatilita_21gg'] = df['Close'].pct_change().rolling(21).std()

# D. Volume Relativo (Volume medio ultimi 5gg vs ultimi 55gg)
df['Volume_Relativo'] = df['Volume'].rolling(5).mean() / df['Volume'].rolling(55).mean()

# E. Contesto FTSE MIB (Forza relativa rispetto all'indice)
mib_perf_21gg = df['MIB_Close'].pct_change(21)
df['Forza_Relativa_MIB'] = df['Perf_21gg'] - mib_perf_21gg

# F. Efficiency Ratio (Qualità del trend a 21gg)
variazione_netta = (df['Close'] - df['Close'].shift(21)).abs()
somma_movimenti = df['Close'].diff().abs().rolling(21).sum()
df['Efficiency_Ratio'] = variazione_netta / somma_movimenti

# G. Internal Bar Strength medio a 5gg
range_giornaliero = (df['High'] - df['Low']).replace(0, np.nan)
ibs = (df['Close'] - df['Low']) / range_giornaliero
df['IBS_5gg'] = ibs.rolling(5).mean()

# H. Correlazione Prezzo-Volume a 21gg
df['Corr_Prezzo_Vol'] = df['Close'].rolling(21).corr(df['Volume'])

# 3. CREAZIONE DEL TARGET (Previsione a 21 giorni)
df['Rendimento_Futuro_21gg'] = df['Close'].shift(-21) / df['Close'] - 1
df['Target'] = (df['Rendimento_Futuro_21gg'] > 0.03).astype(int)

features = [
    'Perf_5gg', 'Perf_21gg', 'Perf_144gg',
    'Dist_SMA21', 'Dist_SMA55', 'Dist_SMA233',
    'Volatilita_21gg', 'Volume_Relativo', 'Forza_Relativa_MIB',
    'Efficiency_Ratio', 'IBS_5gg', 'Corr_Prezzo_Vol'
]

ultimi_dati_oggi = df.dropna(subset=features).iloc[[-1]].copy()
df_modello = df.dropna().copy()

# 4. DIVISIONE TRAIN / TEST (Ordine cronologico rigoroso)
X = df_modello[features]
y = df_modello['Target']

split = int(len(df_modello) * 0.8)
X_train, X_test = X.iloc[:split], X.iloc[split:]
y_train, y_test = y.iloc[:split], y.iloc[split:]

# 5. ADDESTRAMENTO REGRESSIONE LOGISTICA (con StandardScaler)
# C=0.1 applica una regolarizzazione moderata per ridurre il rumore dei dati finanziari
modello = make_pipeline(
    StandardScaler(),
    LogisticRegression(C=0.1, max_iter=1000, random_state=42)
)
modello.fit(X_train, y_train)

# 6. VALUTAZIONE APPROFONDITA
previsioni = modello.predict(X_test)
print(f"\nAccuratezza globale sui dati di test: {accuracy_score(y_test, previsioni):.2%}")

print("\n--- MATRICE DI CONFUSIONE ---")
cm = confusion_matrix(y_test, previsioni)
print(f"Vero NO  (Non salito e previsto NO):  {cm[0][0]}")
print(f"Falso SÌ (Non salito ma previsto SÌ): {cm[0][1]}  <-- Falsi allarmi")
print(f"Falso NO (Salito ma previsto NO):     {cm[1][0]}  <-- Occasioni perse")
print(f"Vero SÌ  (Salito e previsto SÌ):      {cm[1][1]}  <-- Rialzi indovinati")

print("\n--- REPORT DETTAGLIATO ---")
print(classification_report(y_test, previsioni, target_names=['Non Sale (0)', 'Sale >3% (1)'], zero_division=0))

print("\n--- PESO E DIREZIONE DELLE VARIABILI (COEFFICIENTI) ---")
# Estraiamo i coefficienti dal modello dentro la pipeline
logreg = modello.named_steps['logisticregression']
coefficienti = pd.Series(logreg.coef_[0], index=features).sort_values(key=abs, ascending=False)
for nome, valore in coefficienti.items():
    direzione = "Rialzista (+)" if valore > 0 else "Ribassista (-)"
    print(f"{nome:<22}: {valore:+.4f}  [{direzione}]")

# 7. PREVISIONE DI OGGI
probabilita_oggi = modello.predict_proba(ultimi_dati_oggi[features])[0][1]
data_oggi = ultimi_dati_oggi.index[0].strftime('%Y-%m-%d')
print(f"\n--- PREVISIONE OPERATIVA PER IL {data_oggi} ---")
print(f"Probabilità che il titolo salga > 3% nei prossimi 21 giorni: {probabilita_oggi:.2%}")
