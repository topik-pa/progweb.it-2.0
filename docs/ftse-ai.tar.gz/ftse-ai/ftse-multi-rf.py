from pathlib import Path
import yfinance as yf
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix
import warnings

warnings.filterwarnings("ignore")

# Impostazioni principali
SOGLIA = 0.65
PERIODO = "5y"
TARGET = 0.03

# Lista dei principali titoli del FTSE MIB (puoi aggiungere/modificare i ticker .MI)
TITOLI = {
    "CPR.MI": "Campari",
    "UCG.MI": "UniCredit",
    "ISP.MI": "Intesa Sanpaolo",
    "ENEL.MI": "Enel",
    "ENI.MI": "Eni",
    "STLAM.MI": "Stellantis",
    "RACE.MI": "Ferrari",
    "PRY.MI": "Prysmian",
    "LDO.MI": "Leonardo",
    "G.MI": "Generali",
    "MONC.MI": "Moncler",
    "STMMI.MI": "STMicroelectronics"
}

CARTELLA_SCRIPT = Path(__file__).resolve().parent

features = [
    'Perf_5gg', 'Perf_13gg', 'Perf_34gg',
    'Dist_SMA13', 'Dist_SMA34', 'Dist_SMA89',
    'Slope_13', 'Slope_34',
    'Volatilita_21gg', 'Vol_Squeeze', 'Pos_Range_34gg',
    'Volume_Relativo', 'Forza_Relativa_MIB_13', 'Forza_Relativa_MIB_34',
    'Efficiency_Ratio', 'IBS_3gg'
]

def calcola_slope(prezzi, periodo):
    x = np.arange(periodo)
    x_mean = x.mean()
    # Pesi precalcolati per la regressione lineare semplice
    pesi = (x - x_mean) / np.sum((x - x_mean) ** 2)
    return prezzi.rolling(periodo).apply(lambda y: np.dot(y, pesi), raw=True)

print("Scaricamento indice FTSE MIB di riferimento...")
indice_raw = yf.download("FTSEMIB.MI", period=PERIODO, progress=False)
mib_close = indice_raw['Close'].squeeze()

risultati = []

print(f"Analisi in corso su {len(TITOLI)} titoli (Soglia confidenza: {SOGLIA:.0%})...\n")

for ticker, nome in TITOLI.items():
    try:
        FILE_DATI = CARTELLA_SCRIPT / f"dati_{ticker}_{PERIODO}.csv"
        if FILE_DATI.exists():
            print(f"Caricamento dati locali da: {FILE_DATI.name}...")
            df = pd.read_csv(FILE_DATI, index_col=0, parse_dates=True)
        else:
            print(f"File locale non trovato. Scaricamento dati per {ticker} ({PERIODO})...")
            titolo = yf.download(ticker, period=PERIODO, progress=False)
            if titolo.empty or len(titolo) < 300:
                continue

            df = pd.DataFrame()
            df['Close'] = titolo['Close'].squeeze()
            df['High'] = titolo['High'].squeeze()
            df['Low'] = titolo['Low'].squeeze()
            df['Volume'] = titolo['Volume'].squeeze()
            df['MIB_Close'] = mib_close
            df = df.dropna()

            # Salvataggio su disco
            df.to_csv(FILE_DATI)
            print(f"Dati salvati in: {FILE_DATI}")

        # --- 1. FEATURE ENGINEERING (Scala di Fibonacci bilanciata: 3 - 89 giorni) ---

        # A. Momentum multi-orizzonte (5, 13, 34 giorni)
        df['Perf_5gg'] = df['Close'].pct_change(5)
        df['Perf_13gg'] = df['Close'].pct_change(13)
        df['Perf_34gg'] = df['Close'].pct_change(34)

        # B. Distanza da medie mobili strutturali (13, 34, 89 giorni)
        sma_13 = df['Close'].rolling(13).mean()
        sma_34 = df['Close'].rolling(34).mean()
        sma_89 = df['Close'].rolling(89).mean()

        df['Dist_SMA13'] = (df['Close'] - sma_13) / sma_13
        df['Dist_SMA34'] = (df['Close'] - sma_34) / sma_34
        df['Dist_SMA89'] = (df['Close'] - sma_89) / sma_89

        # B2. Slope normalizzata del prezzo
        df['Slope_13'] = calcola_slope(df['Close'], 13) / df['Close']
        df['Slope_34'] = calcola_slope(df['Close'], 34) / df['Close']

        # C. Volatilità a 21gg e Compressione (Volatility Squeeze: 5gg vs 21gg)
        vol_5 = df['Close'].pct_change().rolling(5).std()
        vol_21 = df['Close'].pct_change().rolling(21).std()
        df['Volatilita_21gg'] = vol_21
        df['Vol_Squeeze'] = vol_5 / vol_21.replace(0, np.nan)

        # D. Posizione nel Range a 34 giorni (0 = sui minimi, 1 = sui massimi)
        min_34 = df['Low'].rolling(34).min()
        max_34 = df['High'].rolling(34).max()
        df['Pos_Range_34gg'] = (df['Close'] - min_34) / (max_34 - min_34).replace(0, np.nan)

        # E. Volume Relativo (Breve 5gg vs Medio-lungo 55gg)
        df['Volume_Relativo'] = df['Volume'].rolling(5).mean() / df['Volume'].rolling(55).mean()

        # F. Forza relativa rispetto al FTSE MIB a 13 giorni e 34 giorni
        mib_perf_13gg = df['MIB_Close'].pct_change(13)
        df['Forza_Relativa_MIB_13'] = df['Perf_13gg'] - mib_perf_13gg

        mib_perf_34gg = df['MIB_Close'].pct_change(34)
        df['Forza_Relativa_MIB_34'] = df['Perf_34gg'] - mib_perf_34gg

        # G. Efficiency Ratio a 13 giorni (Qualità direzionale del movimento)
        variazione_netta = (df['Close'] - df['Close'].shift(13)).abs()
        somma_movimenti = df['Close'].diff().abs().rolling(13).sum()
        df['Efficiency_Ratio'] = variazione_netta / somma_movimenti.replace(0, np.nan)

        # H. Internal Bar Strength (IBS) medio a 3 giorni
        range_giornaliero = (df['High'] - df['Low']).replace(0, np.nan)
        ibs = (df['Close'] - df['Low']) / range_giornaliero
        df['IBS_3gg'] = ibs.rolling(3).mean()

        # --- 2. TARGET (+3% raggiunto in almeno uno dei prossimi 21 giorni) ---
        max_futuro_21gg = (
            df['High'].shift(-1)[::-1]
            .rolling(21, min_periods=21).max()[::-1]
        )
        df['Rendimento_Futuro_21gg'] = (
            max_futuro_21gg / df['Close'] - 1
        )
        df['Target'] = np.where(
            df['Rendimento_Futuro_21gg'].notna(),
            (df['Rendimento_Futuro_21gg'] >= TARGET).astype(float),
            np.nan
        )

        ultimi_dati_oggi = df.dropna(subset=features).iloc[[-1]].copy()
        # df_modello = df.dropna().copy()
        df_modello = df.dropna(subset=features + ['Target']).copy()
        df_modello['Target'] = df_modello['Target'].astype(int)

        # --- 3. DIVISIONE TRAIN / TEST CON EMBARGO DI 21 GIORNI ---
        X = df_modello[features]
        y = df_modello['Target']

        split = int(len(df_modello) * 0.8)
        X_train, y_train = X.iloc[:split - 21], y.iloc[:split - 21]
        X_test, y_test = X.iloc[split:], y.iloc[split:]

        # Pesi temporali: dà più importanza agli esempi più recenti (da 0.5 a 1.5)
        pesi_temporali = np.linspace(0.5, 1.5, len(X_train))

        # --- 4. ADDESTRAMENTO RANDOM FOREST ---
        modello = RandomForestClassifier(
            n_estimators=200,
            max_depth=5,
            min_samples_leaf=35,
            random_state=42,
            max_features='sqrt'
        )
        # Eventualmente... class_weight='balanced',
        modello.fit(X_train, y_train, sample_weight=pesi_temporali)

        # --- 5. VALUTAZIONE SUL TEST SET CON SOGLIA ---
        prob_test = modello.predict_proba(X_test)[:, 1]
        prev_test = (prob_test >= SOGLIA).astype(int)
        cm = confusion_matrix(y_test, prev_test, labels=[0, 1])

        vero_si = cm[1, 1]
        falso_si = cm[0, 1]
        segnali_test = vero_si + falso_si
        precisione_test = (vero_si / segnali_test) if segnali_test > 0 else 0.0

        # --- 6. PREVISIONE DI OGGI ---
        prob_oggi = modello.predict_proba(ultimi_dati_oggi[features])[0, 1]
        data_rif = ultimi_dati_oggi.index[0].strftime('%Y-%m-%d')

        risultati.append({
            'Ticker': ticker,
            'Titolo': nome,
            'Data': data_rif,
            'Segnali_Test': segnali_test,
            'Indovinati_Test': vero_si,
            'Precisione_Test': precisione_test,
            'Confidenza_Oggi': prob_oggi,
            'Stato': f'ATTIVO (>={SOGLIA:.0%})' if prob_oggi >= SOGLIA else 'Neutro'
        })

    except Exception as e:
        print(f"Errore su {ticker}: {e}")

# Creiamo e ordiniamo la tabella finale per Confidenza di oggi decrescente
df_risultati = pd.DataFrame(risultati).sort_values(by='Confidenza_Oggi', ascending=False)

print(f"{'TICKER':<10} {'TITOLO':<18} {'DATA':<12} {'TEST (OK/TOT)':<15} {'PREC. TEST':<12} {'OGGI':<9} {'STATO'}")
print("-" * 92)
for _, r in df_risultati.iterrows():
    test_str = f"{r['Indovinati_Test']}/{r['Segnali_Test']}"
    prec_str = f"{r['Precisione_Test']:.1%}" if r['Segnali_Test'] > 0 else "N/D"
    print(f"{r['Ticker']:<10} {r['Titolo']:<18} {r['Data']:<12} {test_str:<15} {prec_str:<12} {r['Confidenza_Oggi']:.1%}     {r['Stato']}")

# --- RIEPILOGO AGGREGATO PANIERE ---
tot_indovinati = df_risultati['Indovinati_Test'].sum()
tot_segnali = df_risultati['Segnali_Test'].sum()
prec_aggregata = (tot_indovinati / tot_segnali) if tot_segnali > 0 else 0.0
segnali_attivi_oggi = (df_risultati['Confidenza_Oggi'] >= SOGLIA).sum()

print("-" * 92)
tot_str = f"{tot_indovinati}/{tot_segnali}"
prec_agg_str = f"{prec_aggregata:.1%}" if tot_segnali > 0 else "N/D"
print(f"{'TOTALE':<10} {'Paniere Completo':<18} {'-':<12} {tot_str:<15} {prec_agg_str:<12} {'-':<9} {segnali_attivi_oggi} ATTIVI")

