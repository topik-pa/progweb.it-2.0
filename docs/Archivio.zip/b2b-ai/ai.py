import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.ensemble import RandomForestClassifier

st.set_page_config(page_title="PredictB2B v4.1 - Vero ML Addestrato sullo Storico", layout="wide")

@st.cache_data
def genera_dati_demo():
    np.random.seed(42)
    n_clienti = 200
    records = []
    oggi = datetime.today()

    for c in range(1, n_clienti + 1):
        cliente_id = f"CLI_{c:03d} - Azienda {c} Srl"
        freq_media = np.random.randint(7, 35)
        importo_medio = np.random.uniform(300, 3500)
        stato = np.random.choice(['abbandonato_passato', 'rischio_attuale', 'sano'], p=[0.30, 0.20, 0.50])
        
        if stato == 'abbandonato_passato':
            stop_date = oggi - timedelta(days=np.random.randint(110, 300))
        elif stato == 'rischio_attuale':
            stop_date = oggi - timedelta(days=np.random.randint(45, 85))
        else:
            stop_date = oggi

        curr_date = oggi - timedelta(days=730)

        while curr_date < stop_date:
            giorni_prima_stop = (stop_date - curr_date).days
            if stato != 'sano' and giorni_prima_stop < 60:
                imp = np.random.normal(importo_medio * 0.5, importo_medio * 0.1)
            else:
                imp = np.random.normal(importo_medio, importo_medio * 0.2)
                
            records.append({
                "id_cliente": cliente_id,
                "data_ordine": curr_date.strftime("%Y-%m-%d"),
                "importo": round(max(50, imp), 2)
            })
            step = max(1, int(np.random.normal(freq_media, freq_media * 0.2)))
            curr_date += timedelta(days=step)

    return pd.DataFrame(records)

def carica_e_pulisci_csv(file):
    prima_riga = file.readline().decode('utf-8', errors='ignore')
    file.seek(0)
    separatore = ';' if ';' in prima_riga else ','
    return pd.read_csv(file, sep=separatore, encoding='utf-8', on_bad_lines='skip')

def normalizza_dati(df, col_cliente, col_data, col_importo):
    df_clean = pd.DataFrame()
    df_clean['id_cliente'] = df[col_cliente].astype(str).str.strip()
    df_clean['data_ordine'] = pd.to_datetime(df[col_data], dayfirst=True, errors='coerce')
    
    importi_str = df[col_importo].astype(str).str.replace('€', '', regex=False).str.strip()
    has_both = importi_str.str.contains(r'\.') & importi_str.str.contains(',')
    importi_str = np.where(has_both, importi_str.str.replace('.', '', regex=False), importi_str)
    importi_str = pd.Series(importi_str).str.replace(',', '.', regex=False)
    
    df_clean['importo'] = pd.to_numeric(importi_str, errors='coerce')
    df_clean = df_clean.dropna(subset=['id_cliente', 'data_ordine', 'importo'])
    return df_clean[df_clean['importo'] > 0]

def estrai_fotografia_al(df, data_taglio):
    storico = df[df['data_ordine'] <= data_taglio].copy()
    if len(storico) == 0:
        return pd.DataFrame()

    storico = storico.sort_values(['id_cliente', 'data_ordine'])
    storico['giorni_tra_ordini'] = storico.groupby('id_cliente')['data_ordine'].diff().dt.days

    feat = storico.groupby('id_cliente').agg(
        primo_ordine=('data_ordine', 'min'),
        ultimo_ordine=('data_ordine', 'max'),
        totale_ordini=('data_ordine', 'count'),
        scontrino_medio_storico=('importo', 'mean'),
        frequenza_media_gg=('giorni_tra_ordini', 'mean'),
        std_frequenza_gg=('giorni_tra_ordini', 'std')
    ).reset_index()

    ultimi_3 = storico.groupby('id_cliente').tail(3).groupby('id_cliente')['importo'].mean().reset_index()
    ultimi_3.rename(columns={'importo': 'scontrino_ultimi_3'}, inplace=True)
    feat = feat.merge(ultimi_3, on='id_cliente', how='left')

    feat['variazione_scontrino_pct'] = np.where(
        (feat['totale_ordini'] >= 4) & (feat['scontrino_medio_storico'] > 0),
        ((feat['scontrino_ultimi_3'] - feat['scontrino_medio_storico']) / feat['scontrino_medio_storico']) * 100,
        0.0
    )

    feat['giorni_da_ultimo_ordine'] = (data_taglio - feat['ultimo_ordine']).dt.days
    feat['anzianita_cliente_gg'] = (data_taglio - feat['primo_ordine']).dt.days
    feat['frequenza_media_gg'] = feat['frequenza_media_gg'].fillna(30).replace(0, 1)
    feat['std_frequenza_gg'] = feat['std_frequenza_gg'].fillna(10)
    feat['rapporto_ritardo'] = feat['giorni_da_ultimo_ordine'] / feat['frequenza_media_gg']

    return feat

def genera_spiegazione(row):
    gg_ritardo = int(row['giorni_da_ultimo_ordine'])
    freq = int(row['frequenza_media_gg'])
    calo = abs(int(row['variazione_scontrino_pct']))

    if row['rapporto_ritardo'] > 1.8 and row['variazione_scontrino_pct'] < -20.0:
        return f"🚨 CRITICO: Spesa calata del {calo}% e ritardo di {gg_ritardo} gg (ritmo: {freq} gg)."
    elif row['rapporto_ritardo'] > 1.8:
        return f"⏳ RITARDO: Ritmo medio di {freq} gg, ma fermo da {gg_ritardo} gg. Intervenire."
    elif row['variazione_scontrino_pct'] < -20.0:
        return f"📉 CALO SPESA: Ordina nei tempi, ma spende il {calo}% in meno del solito."
    else:
        return "⚠️ SEGNALE DEBOLE: Pattern simile a clienti persi in passato."

def addestra_e_predici(df, finestra_osservazione_gg=90):
    data_max = df['data_ordine'].max()
    data_passato = data_max - timedelta(days=finestra_osservazione_gg)

    feat_passato = estrai_fotografia_al(df, data_passato)
    if len(feat_passato) == 0:
        return None, None

    attivi_passato = feat_passato[feat_passato['rapporto_ritardo'] < 2.5].copy()

    futuro_reale = df[(df['data_ordine'] > data_passato) & (df['data_ordine'] <= data_max)]
    spesa_futura = futuro_reale.groupby('id_cliente')['importo'].sum().reset_index()
    spesa_futura.rename(columns={'importo': 'spesa_reale_successiva'}, inplace=True)

    train_df = attivi_passato.merge(spesa_futura, on='id_cliente', how='left')
    train_df['spesa_reale_successiva'] = train_df['spesa_reale_successiva'].fillna(0)
    train_df['spesa_attesa_finestra'] = (finestra_osservazione_gg / train_df['frequenza_media_gg']) * train_df['scontrino_medio_storico']

    train_df['vero_abbandono'] = (
        (train_df['spesa_reale_successiva'] == 0) | 
        (train_df['spesa_reale_successiva'] < train_df['spesa_attesa_finestra'] * 0.4)
    ).astype(int)

    colonne_ml = [
        'totale_ordini', 'anzianita_cliente_gg', 'scontrino_medio_storico',
        'frequenza_media_gg', 'std_frequenza_gg', 'giorni_da_ultimo_ordine',
        'rapporto_ritardo', 'variazione_scontrino_pct'
    ]

    if train_df['vero_abbandono'].nunique() < 2 or len(train_df) < 10:
        return None, None

    X_train = train_df[colonne_ml].fillna(0)
    y_train = train_df['vero_abbandono']

    model = RandomForestClassifier(n_estimators=150, max_depth=6, random_state=42, class_weight='balanced')
    model.fit(X_train, y_train)

    importanza = pd.DataFrame({
        'Fattore': colonne_ml,
        'Peso (%)': np.round(model.feature_importances_ * 100, 1)
    }).sort_values(by='Peso (%)', ascending=False)

    feat_oggi = estrai_fotografia_al(df, data_max)
    attivi_oggi = feat_oggi[feat_oggi['giorni_da_ultimo_ordine'] <= 180].copy()

    if len(attivi_oggi) == 0:
        return None, None

    X_oggi = attivi_oggi[colonne_ml].fillna(0)
    attivi_oggi['probabilita_rischio'] = np.round(model.predict_proba(X_oggi)[:, 1] * 100, 1)
    attivi_oggi['valore_a_rischio_annuo'] = np.round((365 / attivi_oggi['frequenza_media_gg']) * attivi_oggi['scontrino_medio_storico'], 2)
    attivi_oggi['motivo_allarme'] = attivi_oggi.apply(genera_spiegazione, axis=1)

    return attivi_oggi.sort_values(by=['probabilita_rischio', 'valore_a_rischio_annuo'], ascending=False), importanza

# --- INTERFACCIA WEB (STREAMLIT) ---
st.title("🧠 PredictB2B v4.1 — Vero Machine Learning Addestrato sullo Storico")
st.markdown("L'algoritmo studia **cosa è successo realmente negli ultimi mesi** in azienda per scoprire quali comportamenti portano all'abbandono dei clienti.")

st.sidebar.header("1. Sorgente Dati")
uploaded_file = st.sidebar.file_uploader("Carica CSV dal gestionale", type=["csv"])
usa_demo = st.sidebar.checkbox("Usa dati aziendali simulati (Demo 2 anni)", value=True)
finestra_gg = st.sidebar.slider("Finestra di apprendimento storico (giorni)", 60, 180, 90, step=15)

if uploaded_file is not None:
    df_grezzo = carica_e_pulisci_csv(uploaded_file)
    colonne_disp = list(df_grezzo.columns)
    st.sidebar.header("2. Associa le Colonne")
    col_cli = st.sidebar.selectbox("Colonna Cliente", colonne_disp, index=0)
    col_dat = st.sidebar.selectbox("Colonna Data Ordine", colonne_disp, index=min(1, len(colonne_disp)-1))
    col_imp = st.sidebar.selectbox("Colonna Importo (€)", colonne_disp, index=min(2, len(colonne_disp)-1))
    df_raw = normalizza_dati(df_grezzo, col_cli, col_dat, col_imp)
elif usa_demo:
    df_raw = genera_dati_demo()
    df_raw['data_ordine'] = pd.to_datetime(df_raw['data_ordine'])
else:
    st.warning("Carica un file CSV o attiva i dati simulati nella barra laterale.")
    st.stop()

risultati, importanza_fattori = addestra_e_predici(df_raw, finestra_osservazione_gg=finestra_gg)

if risultati is None:
    st.error("Lo storico caricato non contiene abbastanza mesi o clienti passati per addestrare il modello storico (servono almeno 6-12 mesi di ordini e almeno 15 clienti diversi).")
    st.stop()

col1, col2, col3 = st.columns(3)
clienti_critici = risultati[risultati['probabilita_rischio'] > 60]
fatturato_rischio = clienti_critici['valore_a_rischio_annuo'].sum()

col1.metric("Clienti Attivi Analizzati", len(risultati))
col2.metric("Clienti a Rischio Previsionale (>60%)", len(clienti_critici))
col3.metric("Fatturato Annuo a Rischio", f"€ {fatturato_rischio:,.2f}")

with st.expander("🔍 Cosa ha imparato l'AI dallo storico di questa azienda? (Feature Importance)"):
    st.markdown("Ecco quanto pesa ciascun segnale secondo i dati storici reali dell'azienda:")
    st.dataframe(importanza_fattori, use_container_width=True)

st.subheader("🚨 Previsione Abbandoni nei Prossimi 90 Giorni")

tabella_output = clienti_critici[[
    'id_cliente', 'probabilita_rischio', 'valore_a_rischio_annuo',
    'variazione_scontrino_pct', 'giorni_da_ultimo_ordine',
    'frequenza_media_gg', 'motivo_allarme'
]].rename(columns={
    'id_cliente': 'Cliente',
    'probabilita_rischio': 'Prob. Abbandono (%)',
    'valore_a_rischio_annuo': 'Valore Annuo (€)',
    'variazione_scontrino_pct': 'Var. Scontrino (%)',
    'giorni_da_ultimo_ordine': 'Gg da Ultimo Ordine',
    'frequenza_media_gg': 'Ritmo Storico (gg)',
    'motivo_allarme': 'Diagnosi & Azione Consigliata'
})

tabella_output['Var. Scontrino (%)'] = tabella_output['Var. Scontrino (%)'].round(1)
tabella_output['Ritmo Storico (gg)'] = tabella_output['Ritmo Storico (gg)'].round(1)

st.dataframe(tabella_output, use_container_width=True)

csv_esportazione = tabella_output.to_csv(index=False, sep=';', decimal=',').encode('utf-8-sig')
st.download_button(
    label="📥 Scarica Lista Azioni per Venditori (Excel)",
    data=csv_esportazione,
    file_name=f"Previsione_Churn_AI_{datetime.today().strftime('%Y%m%d')}.csv",
    mime="text/csv"
)

