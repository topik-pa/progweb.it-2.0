from pathlib import Path
import yfinance as yf
import pandas as pd
import numpy as np
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import warnings

# Impostazioni principali
SOGLIA = 0.50
PERIODO = "10y"
TARGET = 0.05
WARMUP = 89
ORIZZONTE = 21
TITOLO = "LDO.MI"

CARTELLA_SCRIPT = Path(__file__).resolve().parent
FILE_DATI = CARTELLA_SCRIPT / f"dati_{TITOLO}_{PERIODO}.csv"


# def calcola_slope(prezzi, periodo):
#     x = np.arange(periodo)
#     x_mean = x.mean()
#     # Pesi precalcolati per la regressione lineare semplice
#     pesi = (x - x_mean) / np.sum((x - x_mean) ** 2)
#     return prezzi.rolling(periodo).apply(lambda y: np.dot(y, pesi), raw=True)  

if FILE_DATI.exists():
    print(f"Caricamento dati locali da: {FILE_DATI.name}...")
    df = pd.read_csv(FILE_DATI, index_col=0, parse_dates=True)
else:
    print(f"File locale non trovato. Scaricamento dati per {TITOLO} ({PERIODO})...")
    titolo = yf.download(TITOLO, period=PERIODO, progress=False)
    indice = yf.download("FTSEMIB.MI", period=PERIODO, progress=False)

    # Pulizia e allineamento
    df = pd.DataFrame()
    df['Open'] = titolo['Open'].squeeze()
    df['Close'] = titolo['Close'].squeeze()
    df['High'] = titolo['High'].squeeze()
    df['Low'] = titolo['Low'].squeeze()
    df['Volume'] = titolo['Volume'].squeeze()
    df['MIB_Close'] = indice['Close'].squeeze()
    df = df.dropna()

    # Salvataggio su disco
    df.to_csv(FILE_DATI)
    print(f"Dati salvati in: {FILE_DATI}")

df = df.sort_index()
if df.index.has_duplicates:
    raise ValueError("Sono presenti date duplicate")
if df.empty:
    raise ValueError("Il dataset è vuoto")

# --- 1. FEATURE ENGINEERING (Scala di Fibonacci bilanciata: 3 - 89 giorni) ---

# A. Momentum multi-orizzonte (Breve, Medio, Trimestrale: 5, 13, 34 giorni)
# df['Perf_5gg'] = df['Close'].pct_change(5)
df['Perf_13gg'] = df['Close'].pct_change(13)
# df['Perf_34gg'] = df['Close'].pct_change(34)

# B. Distanza da medie mobili strutturali (13, 34, 89 giorni)
# sma_13 = df['Close'].rolling(13).mean()
# sma_34 = df['Close'].rolling(34).mean()
# sma_89 = df['Close'].rolling(89).mean()

# df['Dist_SMA13'] = (df['Close'] - sma_13) / sma_13
# df['Dist_SMA34'] = (df['Close'] - sma_34) / sma_34
# df['Dist_SMA89'] = (df['Close'] - sma_89) / sma_89

# B2. Slope normalizzata del prezzo
# df['Slope_13'] = calcola_slope(df['Close'], 13) / df['Close']
# df['Slope_34'] = calcola_slope(df['Close'], 34) / df['Close']

# C. Volatilità a 21gg e Compressione (Volatility Squeeze: 5gg vs 21gg)
# vol_5 = df['Close'].pct_change().rolling(5).std()
# vol_21 = df['Close'].pct_change().rolling(21).std()
# df['Volatilita_21gg'] = vol_21
# df['Vol_Squeeze'] = vol_5 / vol_21.replace(0, np.nan)

# D. Posizione nel Range a 34 giorni (0 = sui minimi, 1 = sui massimi)
# min_34 = df['Low'].rolling(34).min()
# max_34 = df['High'].rolling(34).max()
# df['Pos_Range_34gg'] = (df['Close'] - min_34) / (max_34 - min_34).replace(0, np.nan)

# E. Volume Relativo (Breve 5gg vs Medio-lungo 55gg)
# df['Volume_Relativo'] = df['Volume'].rolling(5).mean() / df['Volume'].rolling(55).mean()

# F. Forza relativa rispetto al FTSE MIB a 13 giorni
# mib_perf_13gg = df['MIB_Close'].pct_change(13)
# df['Forza_Relativa_MIB_13'] = df['Perf_13gg'] - mib_perf_13gg

# mib_perf_34gg = df['MIB_Close'].pct_change(34)
# df['Forza_Relativa_MIB_34'] = df['Perf_34gg'] - mib_perf_34gg

# G. Efficiency Ratio a 13 giorni (Qualità direzionale del movimento)
# variazione_netta = (df['Close'] - df['Close'].shift(13)).abs()
# somma_movimenti = df['Close'].diff().abs().rolling(13).sum()
# df['Efficiency_Ratio'] = variazione_netta / somma_movimenti.replace(0, np.nan)

# H. Internal Bar Strength (IBS) medio a 3 giorni (Tempismo di ingresso)
# range_giornaliero = (df['High'] - df['Low']).replace(0, np.nan)
# ibs = (df['Close'] - df['Low']) / range_giornaliero
# df['IBS_3gg'] = ibs.rolling(3).mean()

# J. Gap di prezzo giornaliero
# gap_percentuale = (
#     df['Open'] / df['Close'].shift(1) - 1
# )
# SOGLIA_GAP = 0.005  # 0,5%
# gap_up = gap_percentuale.where(
#     gap_percentuale >= SOGLIA_GAP, 0
# )
# gap_down = (-gap_percentuale).where(
#     gap_percentuale <= -SOGLIA_GAP, 0
# )
# # Gap Up e Down negli ultimi 34 giorni
# df['Gap_Up_34gg'] = (
#     (gap_up > 0).rolling(34).sum()
# )
# df['Gap_Down_34gg'] = (
#     (gap_down > 0).rolling(34).sum()
# )
# Dimensione massima dei gap negli ultimi 34 giorni
# df['Max_Gap_Up_34gg'] = (
#     gap_up.rolling(34).max()
# )
# df['Max_Gap_Down_34gg'] = (
#     gap_down.rolling(34).max()
# )

#--- 2. TARGET (+5% raggiunto in almeno uno dei prossimi 21 giorni) ---
max_futuro_21gg = (
    df['High'].shift(-1)[::-1]
    .rolling(ORIZZONTE, min_periods=ORIZZONTE).max()[::-1]
)
df['Rendimento_Futuro_21gg'] = (
    max_futuro_21gg / df['Close'] - 1
)
df['Target'] = np.where(
    df['Rendimento_Futuro_21gg'].notna(),
    (df['Rendimento_Futuro_21gg'] >= TARGET).astype(float),
    np.nan
)

features = [
    'Perf_13gg'
]
# features = [
#     'Perf_5gg', 'Perf_13gg', 'Perf_34gg',
#     'Dist_SMA13', 'Dist_SMA34', 'Dist_SMA89',
#     'Slope_13', 'Slope_34',
#     'Volatilita_21gg', 'Vol_Squeeze', 'Pos_Range_34gg',
#     'Volume_Relativo', 'Forza_Relativa_MIB_13', 'Forza_Relativa_MIB_34',
#     'Efficiency_Ratio', 'IBS_3gg',
#     'Gap_Up_34gg', 'Gap_Down_34gg', 'Max_Gap_Up_34gg', 'Max_Gap_Down_34gg'
# ]

ultimi_dati_oggi = df.dropna(subset=features).iloc[[-1]].copy()
data_oggi = ultimi_dati_oggi.index[0]
print(f"Data utilizzata per la previsione: {data_oggi:%Y-%m-%d}")
df_modello = df.dropna(subset=features + ['Target']).copy()
df_modello['Target'] = df_modello['Target'].astype(int)

# --- 3. DIVISIONE TRAIN / TEST CON EMBARGO DI 21 GIORNI ---
# --- DIVISIONE TRAIN / TEST ---

df_base = df.dropna(subset=['Target'])

split = int(len(df_base) * 0.8)

df_train = df_base.iloc[
    WARMUP:split - ORIZZONTE
].dropna(subset=features)

df_test = df_base.iloc[
    split:
].dropna(subset=features)

X_train = df_train[features]
y_train = df_train['Target'].astype(int)

X_test = df_test[features]
y_test = df_test['Target'].astype(int)


print("\n--- PERIODI DI ANALISI ---")
print(f"Train: {X_train.index.min()} - {X_train.index.max()}")
print(f"Test:  {X_test.index.min()} - {X_test.index.max()}")
print(f"Osservazioni Train: {len(X_train)}")
print(f"Osservazioni Test:  {len(X_test)}")


# --- ANALISI DISTRIBUZIONE TRAIN / TEST ---

analisi_distribuzione = pd.DataFrame({
    'Train_Min': X_train.min(),
    'Train_Max': X_train.max(),
    'Train_Median': X_train.median(),
    'Test_Min': X_test.min(),
    'Test_Max': X_test.max(),
    'Test_Median': X_test.median(),
    'Test_Fuori_Range': (
        (X_test < X_train.min()) |
        (X_test > X_train.max())
    ).mean() * 100
})

print("\n--- DISTRIBUZIONE FEATURE TRAIN / TEST ---")
print(analisi_distribuzione.round(2).to_string())

print("\n--- DISTRIBUZIONE DEL TARGET ---")
print(f"Base Rate Train: {y_train.mean():.2%}")
print(f"Base Rate Test:  {y_test.mean():.2%}")



# Pesi temporali: dà più importanza agli esempi più recenti (da 0.5 a 1.5)
pesi_temporali = np.linspace(0.5, 1.5, len(X_train))

# --- 4. ADDESTRAMENTO RANDOM FOREST ---
modello = RandomForestClassifier(
    n_estimators=200,
    max_depth=5,
    min_samples_leaf=35,
    random_state=42,
    max_features='sqrt'
)
# Eventualmente... class_weight='balanced',
modello.fit(X_train, y_train, sample_weight=pesi_temporali)

# --- 5. VALUTAZIONE SUL TEST SET ---
probabilita_test = modello.predict_proba(X_test)[:, 1]
previsioni = (probabilita_test >= SOGLIA).astype(int)

# --- DISTRIBUZIONE DELLE PROBABILITÀ ---

print("\n--- DISTRIBUZIONE DELLE PROBABILITÀ ---")

print(pd.Series(probabilita_test).describe(
    percentiles=[0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99]
).round(4))

print(f"Probabilità >= 50%: {(probabilita_test >= 0.50).sum()}")

print(f"\n=== RISULTATI SU {TITOLO} (Soglia {SOGLIA:.0%}) ===")
print(f"Giorni nel Test Set: {len(y_test)} | Accuratezza globale: {accuracy_score(y_test, previsioni):.2%}")

cm = confusion_matrix(y_test, previsioni, labels=[0, 1])
print("\n--- MATRICE DI CONFUSIONE ---")
print(f"Vero NO  (Non salito e previsto NO):  {cm[0][0]}")
print(f"Falso SÌ (Non salito ma previsto SÌ): {cm[0][1]}  <-- Falsi allarmi")
print(f"Falso NO (Salito ma previsto NO):     {cm[1][0]}  <-- Occasioni perse")
print(f"Vero SÌ  (Salito e previsto SÌ):      {cm[1][1]}  <-- Rialzi indovinati")

print("\n--- REPORT DETTAGLIATO ---")
print(classification_report(
    y_test,
    previsioni,
    labels=[0, 1],
    target_names=[
        'Target non raggiunto (0)',
        f'Target +{TARGET:.0%} raggiunto (1)'
    ],
    zero_division=0
))

# --- VALUTAZIONE DEI SEGNALI POSITIVI ---
tn, fp, fn, tp = cm.ravel()
totale_test = len(y_test)
numero_segnali = tp + fp
# Probabilità naturale dell'evento
base_rate = y_test.mean()
# Precisione dei segnali positivi
precisione = (
    tp / numero_segnali
    if numero_segnali > 0 else np.nan
)
# Vantaggio statistico assoluto
edge = precisione - base_rate
# Vantaggio statistico relativo
lift = (
    precisione / base_rate
    if base_rate > 0 else np.nan
)
# Frequenza dei segnali
signal_rate = numero_segnali / totale_test
# Percentuale di opportunità intercettate
recall = (
    tp / (tp + fn)
    if (tp + fn) > 0 else np.nan
)
print("\n--- VALUTAZIONE DEI SEGNALI POSITIVI ---")
print(f"Osservazioni nel test:     {totale_test}")
print(f"Segnali generati:          {numero_segnali}")
print(f"Segnali corretti:          {tp}")
print(f"Segnali errati:            {fp}")
print(f"Base Rate:                 {base_rate:.2%}")
print(f"Precision:                 {precisione:.2%}")
print(f"Edge statistico:           {edge * 100:+.2f} p.p.")
print(f"Lift:                      {lift:.2f}x")
print(f"Recall:                    {recall:.2%}")
print(f"Signal Rate:               {signal_rate:.2%}")

print("\n--- TOP 5 VARIABILI PIÙ RILEVANTI ---")
importanza = pd.Series(modello.feature_importances_, index=features).sort_values(ascending=False)
for nome, valore in importanza.head(5).items():
    print(f"{nome:<22}: {valore:.2%}")

# --- 6. PREVISIONE DI OGGI ---
probabilita_oggi = modello.predict_proba(ultimi_dati_oggi[features])[0][1]
data_oggi = ultimi_dati_oggi.index[0].strftime('%Y-%m-%d')
segnale_oggi = "SEGNALE POSITIVO (Supera soglia)" if probabilita_oggi >= SOGLIA else "NESSUN SEGNALE (Sotto soglia)"

print(f"\n--- PREVISIONE OPERATIVA PER IL {data_oggi} ---")
print(f"Confidenza del modello: {probabilita_oggi:.2%}")
print(f"Esito filtro (>={SOGLIA:.0%}):  {segnale_oggi}")


# --- ANALISI DEI SEGNALI GENERATI ---

df_segnali = df_modello.loc[X_test.index, [
    'Close',
    'Rendimento_Futuro_21gg',
    'Target'
]].copy()

df_segnali['Probabilita'] = probabilita_test

df_segnali = df_segnali[
    df_segnali['Probabilita'] >= SOGLIA
]

print("\n--- DETTAGLIO SEGNALI POSITIVI ---")
print(df_segnali.to_string())


# --- CLASSIFICATORE DI RIFERIMENTO ---

dummy = DummyClassifier(strategy='most_frequent')
dummy.fit(X_train, y_train)

accuracy_dummy = dummy.score(X_test, y_test)
accuracy_rf = accuracy_score(y_test, previsioni)

print("\n--- CONFRONTO CON DUMMY CLASSIFIER ---")
print(f"Accuracy Dummy:         {accuracy_dummy:.2%}")
print(f"Accuracy Random Forest: {accuracy_rf:.2%}")
print(f"Vantaggio Random Forest: {(accuracy_rf - accuracy_dummy) * 100:+.2f} p.p.")

