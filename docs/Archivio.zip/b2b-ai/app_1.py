import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.ensemble import RandomForestClassifier

st.set_page_config(page_title="PredictB2B v2.0 - Radar Churn & Calo Spesa", layout="wide")

# --- 1. GENERATORE DATI DEMO REALISTICI (CON CHURN SILENZIOSO) ---
@st.cache_data
def genera_dati_demo():
    np.random.seed(42)
    n_clienti = 150
    records = []
    oggi = datetime.today()

    for c in range(1, n_clienti + 1):
        cliente_id = f"CLI_{c:03d} - Azienda {c} Srl"
        freq_media = np.random.randint(7, 45)
        importo_medio = np.random.uniform(300, 3500)

        # 3 scenari: 20% abbandono totale, 20% calo spesa silenzioso, 60% regolari
        scenario = np.random.choice(['abbandono', 'calo_spesa', 'regolare'], p=[0.20, 0.20, 0.60])
        
        stop_date = oggi - timedelta(days=np.random.randint(65, 140)) if scenario == 'abbandono' else oggi
        curr_date = oggi - timedelta(days=730)

        while curr_date < stop_date:
            # Se è in "calo_spesa", negli ultimi 75 giorni riduce gli ordini del 45-65%
            if scenario == 'calo_spesa' and (oggi - curr_date).days < 75:
                imp = np.random.normal(importo_medio * 0.45, importo_medio * 0.1)
            else:
                imp = np.random.normal(importo_medio, importo_medio * 0.2)
                
            records.append({
                "id_cliente": cliente_id,
                "data_ordine": curr_date.strftime("%Y-%m-%d"),
                "importo": round(max(50, imp), 2)
            })
            curr_date += timedelta(days=int(np.random.normal(freq_media, freq_media * 0.2)))

    return pd.DataFrame(records)

# --- 2. FEATURE ENGINEERING AVANZATA ---
def prepara_features(df):
    df['data_ordine'] = pd.to_datetime(df['data_ordine'])
    data_rif = df['data_ordine'].max()

    df = df.sort_values(['id_cliente', 'data_ordine'])
    df['giorni_tra_ordini'] = df.groupby('id_cliente')['data_ordine'].diff().dt.days

    # Calcolo base per cliente
    features = df.groupby('id_cliente').agg(
        ultimo_ordine=('data_ordine', 'max'),
        totale_ordini=('data_ordine', 'count'),
        fatturato_totale=('importo', 'sum'),
        scontrino_medio_storico=('importo', 'mean'),
        frequenza_media_gg=('giorni_tra_ordini', 'mean')
    ).reset_index()

    # Calcolo media ultimi 3 ordini vs ordini precedenti (per scovare il calo silenzioso)
    ultimi_3 = df.groupby('id_cliente').tail(3).groupby('id_cliente')['importo'].mean().reset_index()
    ultimi_3.rename(columns={'importo': 'scontrino_ultimi_3'}, inplace=True)
    
    features = features.merge(ultimi_3, on='id_cliente', how='left')

    # Variazione percentuale dello scontrino recente rispetto allo storico
    features['variazione_scontrino_pct'] = np.where(
        features['totale_ordini'] >= 4,
        ((features['scontrino_ultimi_3'] - features['scontrino_medio_storico']) / features['scontrino_medio_storico']) * 100,
        0.0
    )

    features['giorni_da_ultimo_ordine'] = (data_rif - features['ultimo_ordine']).dt.days
    features['frequenza_media_gg'] = features['frequenza_media_gg'].fillna(30)
    features['rapporto_ritardo'] = features['giorni_da_ultimo_ordine'] / features['frequenza_media_gg']

    # Target storico: scatta se è in forte ritardo (>2.2x) OPPURE se lo scontrino è calato oltre il 30%
    cond_ritardo = features['rapporto_ritardo'] > 2.2
    cond_calo_spesa = features['variazione_scontrino_pct'] < -30.0
    features['target_abbandono'] = (cond_ritardo | cond_calo_spesa).astype(int)

    return features

# --- 3. MOTORE PREDITTIVO & SPIEGAZIONE AUTOMATICA ---
def genera_spiegazione(row):
    gg_ritardo = int(row['giorni_da_ultimo_ordine'])
    freq = int(row['frequenza_media_gg'])
    calo = abs(int(row['variazione_scontrino_pct']))
    ordini_saltati = max(1, round(gg_ritardo / max(1, freq)))

    # Caso 1: Sia in ritardo che con spesa ridotta (Situazione critica)
    if row['rapporto_ritardo'] > 2.0 and row['variazione_scontrino_pct'] < -25.0:
        return f"🚨 CRITICO: Ha ridotto la spesa del {calo}% e ora è fermo da {gg_ritardo} gg. Chiamare subito per evitare perdita totale."
    
    # Caso 2: Ha smesso di ordinare (Ritardo rispetto al ritmo)
    elif row['rapporto_ritardo'] > 2.0:
        return f"⏳ RITARDO: Ordina di solito ogni {freq} gg, ma non si sente da {gg_ritardo} gg (ha saltato circa {ordini_saltati} ordini). Verificare passaggio a concorrente."
    
    # Caso 3: Continua a ordinare ma spende molto meno (Churn silenzioso)
    elif row['variazione_scontrino_pct'] < -25.0:
        return f"📉 CALO SPESA: Ordina regolarmente ma spende il {calo}% in meno rispetto ai suoi {int(row['scontrino_medio_storico'])}€ abituali. Possibile concorrente su prodotti chiave."
    
    else:
        return "⚠️ MONITORARE: Leggero rallentamento rispetto alle abitudini storiche."


def esegui_predizione(features):
    X = features[[
        'totale_ordini', 'scontrino_medio_storico', 'frequenza_media_gg',
        'giorni_da_ultimo_ordine', 'rapporto_ritardo', 'variazione_scontrino_pct'
    ]]
    y = features['target_abbandono']

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X, y)

    features['probabilita_rischio'] = np.round(model.predict_proba(X)[:, 1] * 100, 1)
    features['valore_a_rischio_annuo'] = np.round((365 / features['frequenza_media_gg']) * features['scontrino_medio_storico'], 2)
    features['motivo_allarme'] = features.apply(genera_spiegazione, axis=1)

    return features.sort_values(by=['probabilita_rischio', 'valore_a_rischio_annuo'], ascending=False)

# --- 4. INTERFACCIA WEB (STREAMLIT) ---
st.title("📊 PredictB2B v2.0 — Radar Abbandono & Calo Spesa")
st.markdown("Individua sia i clienti che **hanno smesso di ordinare**, sia quelli che stanno **riducendo silenziosamente la spesa**.")

uploaded_file = st.sidebar.file_uploader("Carica il CSV del gestionale", type=["csv"])
usa_demo = st.sidebar.checkbox("Usa dati aziendali simulati (Demo)", value=True)

if uploaded_file is not None:
    df_raw = pd.read_csv(uploaded_file)
elif usa_demo:
    df_raw = genera_dati_demo()
else:
    st.warning("Carica un file CSV o attiva i dati simulati nella barra laterale.")
    st.stop()

df_feat = prepara_features(df_raw)
risultati = esegui_predizione(df_feat)

# KPI Principali
col1, col2, col3, col4 = st.columns(4)
clienti_critici = risultati[risultati['probabilita_rischio'] > 60]
clienti_calo = clienti_critici[clienti_critici['variazione_scontrino_pct'] < -25]
fatturato_rischio = clienti_critici['valore_a_rischio_annuo'].sum()

col1.metric("Clienti Analizzati", len(risultati))
col2.metric("Clienti a Rischio Totale", len(clienti_critici))
col3.metric("Di cui per Calo Spesa", len(clienti_calo))
col4.metric("Fatturato Annuo a Rischio", f"€ {fatturato_rischio:,.2f}")

st.subheader("🚨 Lista Prioritaria per la Rete Vendita")

tabella_output = clienti_critici[[
    'id_cliente', 'probabilita_rischio', 'valore_a_rischio_annuo',
    'variazione_scontrino_pct', 'giorni_da_ultimo_ordine',
    'frequenza_media_gg', 'motivo_allarme'
]].rename(columns={
    'id_cliente': 'Cliente',
    'probabilita_rischio': 'Rischio (%)',
    'valore_a_rischio_annuo': 'Valore Annuo (€)',
    'variazione_scontrino_pct': 'Var. Scontrino (%)',
    'giorni_da_ultimo_ordine': 'Gg da Ultimo Ordine',
    'frequenza_media_gg': 'Ritmo Storico (gg)',
    'motivo_allarme': 'Diagnosi & Azione Consigliata'
})

# Formattazione numerica pulita
tabella_output['Var. Scontrino (%)'] = tabella_output['Var. Scontrino (%)'].round(1)
tabella_output['Ritmo Storico (gg)'] = tabella_output['Ritmo Storico (gg)'].round(1)

st.dataframe(tabella_output, use_container_width=True)
