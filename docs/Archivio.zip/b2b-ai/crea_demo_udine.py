import pandas as pd
import numpy as np
from datetime import datetime, timedelta

np.random.seed(42)

# Nomi realistici per il territorio di Udine e provincia
tipologie = ["Bar", "Osteria", "Ristorante", "Pizzeria", "Caffè", "Trattoria", "Hotel", "Birreria", "Pasticceria", "Gastronomia"]
nomi = [
    "Al Castello", "San Giacomo", "Piazza Matteotti", "Al Fogolar", "Del Torre", "Al Natisone",
    "Alla Posta", "Da Nando", "Al Ponte", "La Pergola", "Il Giardino", "Al Tagliamento",
    "Centrale", "Stazione", "Duomo", "Mercato Vecchio", "Aquileia", "Friuli", "Carnia",
    "Al Municipio", "Vecchia Udine", "Il Borgo", "Alla Fontana", "Al Campanile", "Moderno"
]
comuni = [
    "Udine", "Tavagnacco", "Cividale del Friuli", "Codroipo", "Gemona del Friuli",
    "Tolmezzo", "Tarcento", "Latisana", "San Daniele del Friuli", "Cervignano del Friuli",
    "Palmanova", "Tricesimo", "Pasian di Prato", "Martignacco", "Campoformido"
]

clienti_unici = []
for i in range(1, 121):
    t = np.random.choice(tipologie)
    n = np.random.choice(nomi)
    c = np.random.choice(comuni)
    ragione_sociale = f"{t} {n} ({c}) - CLI_{i:03d}"
    clienti_unici.append(ragione_sociale)

records = []
oggi = datetime(2026, 11, 10)

for idx, cliente in enumerate(clienti_unici):
    freq_media = np.random.randint(7, 28)
    importo_medio = np.random.uniform(350, 2800)
    
    # Assegna scenari realistici
    if idx < 35:
        stato = 'abbandonato_passato'  # Serve al ML per imparare
        stop_date = oggi - timedelta(days=np.random.randint(105, 280))
    elif idx < 50:
        stato = 'ritardo_attuale'      # Allarme ritardo oggi
        stop_date = oggi - timedelta(days=np.random.randint(45, 75))
    elif idx < 62:
        stato = 'calo_spesa_attuale'   # Allarme calo spesa silenzioso oggi
        stop_date = oggi - timedelta(days=np.random.randint(2, 12))
    else:
        stato = 'sano'                 # Clienti regolari
        stop_date = oggi - timedelta(days=np.random.randint(1, 15))

    curr_date = oggi - timedelta(days=730)

    while curr_date <= stop_date:
        giorni_alla_fine = (stop_date - curr_date).days
        
        if stato in ['abbandonato_passato', 'ritardo_attuale'] and giorni_alla_fine < 45:
            imp = np.random.normal(importo_medio * 0.65, importo_medio * 0.1)
        elif stato == 'calo_spesa_attuale' and giorni_alla_fine < 65:
            imp = np.random.normal(importo_medio * 0.45, importo_medio * 0.08)
        else:
            imp = np.random.normal(importo_medio, importo_medio * 0.18)

        # Formatta all'italiana come un vero gestionale
        data_it = curr_date.strftime("%d/%m/%Y")
        imp_val = round(max(60.0, imp), 2)
        imp_it = f"{imp_val:,.2f} €".replace(",", "X").replace(".", ",").replace("X", ".")

        records.append({
            "Ragione_Sociale": cliente,
            "Data_Fattura": data_it,
            "Imponibile_Netto": imp_it
        })

        step = max(2, int(np.random.normal(freq_media, freq_media * 0.15)))
        curr_date += timedelta(days=step)

df = pd.DataFrame(records)
df = df.sample(frac=1, random_state=42).reset_index(drop=True) # Mescola le righe come un vero export
df.to_csv("demo_distributore_udine.csv", sep=";", index=False, encoding="utf-8-sig")
print(f"Creato file 'demo_distributore_udine.csv' con {len(df)} fatture e {len(clienti_unici)} clienti!")
