import yfinance as yf
import pandas as pd
import numpy as np
from itertools import product
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import (
    average_precision_score,
    precision_score,
    recall_score,
    classification_report,
    confusion_matrix
)
import warnings

warnings.filterwarnings("ignore")

# Impostazioni principali
PERIODO = "5y"
TITOLO = "STMMI.MI"
ORIZZONTE_TARGET = 21
N_SPLITS = 5
MIN_SEGNALI_RICHIESTI = 15

def calcola_slope_veloce(serie, periodo):
    x = np.arange(periodo)
    x_mean = x.mean()
    pesi = (x - x_mean) / np.sum((x - x_mean) ** 2)
    return serie.rolling(periodo).apply(lambda y: np.dot(y, pesi), raw=True)

print(f"Scaricamento dati per {TITOLO} ({PERIODO})...")
titolo = yf.download(TITOLO, period=PERIODO, auto_adjust=True, progress=False)
indice = yf.download("FTSEMIB.MI", period=PERIODO, auto_adjust=True, progress=False)

# Pulizia e allineamento
df = pd.DataFrame(index=titolo.index)
df['Close'] = titolo['Close'].squeeze()
df['High'] = titolo['High'].squeeze()
df['Low'] = titolo['Low'].squeeze()
df['Volume'] = titolo['Volume'].squeeze()
df['MIB_Close'] = indice['Close'].squeeze().reindex(titolo.index).ffill()
df = df.dropna()

# --- 1. FEATURE ENGINEERING ---
df['Perf_5gg'] = df['Close'].pct_change(5)
df['Perf_13gg'] = df['Close'].pct_change(13)
df['Perf_34gg'] = df['Close'].pct_change(34)

sma_13 = df['Close'].rolling(13).mean()
sma_34 = df['Close'].rolling(34).mean()
sma_89 = df['Close'].rolling(89).mean()

df['Dist_SMA13'] = (df['Close'] - sma_13) / sma_13
df['Dist_SMA34'] = (df['Close'] - sma_34) / sma_34
df['Dist_SMA89'] = (df['Close'] - sma_89) / sma_89

df['Slope_13'] = calcola_slope_veloce(df['Close'], 13) / df['Close']
df['Slope_34'] = calcola_slope_veloce(df['Close'], 34) / df['Close']

vol_5 = df['Close'].pct_change().rolling(5).std()
vol_21 = df['Close'].pct_change().rolling(21).std()
df['Volatilita_21gg'] = vol_21
df['Vol_Squeeze'] = vol_5 / vol_21.replace(0, np.nan)

min_34 = df['Low'].rolling(34).min()
max_34 = df['High'].rolling(34).max()
df['Pos_Range_34gg'] = (df['Close'] - min_34) / (max_34 - min_34).replace(0, np.nan)

vol_media_55 = df['Volume'].rolling(55).mean().replace(0, np.nan)
df['Volume_Relativo'] = df['Volume'].rolling(5).mean() / vol_media_55

df['Forza_Relativa_MIB_13'] = df['Perf_13gg'] - df['MIB_Close'].pct_change(13)
df['Forza_Relativa_MIB_34'] = df['Perf_34gg'] - df['MIB_Close'].pct_change(34)

variazione_netta = (df['Close'] - df['Close'].shift(13)).abs()
somma_movimenti = df['Close'].diff().abs().rolling(13).sum().replace(0, np.nan)
df['Efficiency_Ratio'] = variazione_netta / somma_movimenti

range_giornaliero = (df['High'] - df['Low']).replace(0, np.nan)
ibs = (df['Close'] - df['Low']) / range_giornaliero
df['IBS_3gg'] = ibs.rolling(3).mean()

# --- 2. TARGET ---
max_futuro_21gg = (
    df['High'].shift(-1)[::-1]
    .rolling(ORIZZONTE_TARGET, min_periods=ORIZZONTE_TARGET).max()[::-1]
)
df['Rendimento_Futuro_21gg'] = max_futuro_21gg / df['Close'] - 1
df['Target'] = np.where(
    df['Rendimento_Futuro_21gg'].notna(),
    (df['Rendimento_Futuro_21gg'] >= 0.03).astype(float),
    np.nan
)

features = [
    'Perf_5gg', 'Perf_13gg', 'Perf_34gg',
    'Dist_SMA13', 'Dist_SMA34', 'Dist_SMA89',
    'Slope_13', 'Slope_34',
    'Volatilita_21gg', 'Vol_Squeeze', 'Pos_Range_34gg',
    'Volume_Relativo', 'Forza_Relativa_MIB_13', 'Forza_Relativa_MIB_34',
    'Efficiency_Ratio', 'IBS_3gg'
]

ultimi_dati_oggi = df.dropna(subset=features).iloc[[-1]].copy()
df_modello = df.dropna(subset=features + ['Target']).copy()
df_modello['Target'] = df_modello['Target'].astype(int)

X = df_modello[features]
y = df_modello['Target']

# --- 3. GRID SEARCH TEMPORALE (OTTIMIZZAZIONE IPERPARAMETRI) ---
griglia_parametri = {
    'max_depth': (3, 4, 5, 6),
    'min_samples_leaf': (10, 20, 35),
    'max_features': ('sqrt', 0.5)
}

combinazioni = list(product(
    griglia_parametri['max_depth'],
    griglia_parametri['min_samples_leaf'],
    griglia_parametri['max_features']
))

tscv = TimeSeriesSplit(n_splits=N_SPLITS, gap=ORIZZONTE_TARGET)

miglior_score = -1
migliori_parametri = None
migliori_prob_oos = None
y_oos_reale = None

print(f"\n=== OTTIMIZZAZIONE IPERPARAMETRI ({len(combinazioni)} combinazioni in Walk-Forward) ===")

for depth, leaf, max_feat in combinazioni:
    y_test_list = []
    prob_list = []
    
    for train_idx, test_idx in tscv.split(X):
        X_train, y_train = X.iloc[train_idx], y.iloc[train_idx]
        X_test, y_test = X.iloc[test_idx], y.iloc[test_idx]
        
        pesi = np.linspace(0.5, 1.5, len(X_train))
        
        clf = RandomForestClassifier(
            n_estimators=200,
            max_depth=depth,
            min_samples_leaf=leaf,
            max_features=max_feat,
            random_state=42,
            n_jobs=-1
        )
        clf.fit(X_train, y_train, sample_weight=pesi)
        
        prob = clf.predict_proba(X_test)[:, 1]
        y_test_list.extend(y_test)
        prob_list.extend(prob)
    
    y_arr = np.array(y_test_list)
    prob_arr = np.array(prob_list)
    
    pr_auc = average_precision_score(y_arr, prob_arr)
    
    if pr_auc > miglior_score:
        miglior_score = pr_auc
        migliori_parametri = {
            'max_depth': depth,
            'min_samples_leaf': leaf,
            'max_features': max_feat
        }
        migliori_prob_oos = prob_arr
        y_oos_reale = y_arr

print(f"Miglior PR-AUC Out-Of-Sample: {miglior_score:.4f}")
print(f"Migliori iperparametri trovati: {migliori_parametri}")

# --- 4. OTTIMIZZAZIONE DELLA SOGLIA DI CONFIDENZA ---
print(f"\n=== ANALISI SENSIBILITÀ SOGLIA (Minimo {MIN_SEGNALI_RICHIESTI} segnali) ===")
print(f"{'Soglia':<8} | {'Segnali':<8} | {'Precisione':<12} | {'Recall':<8} | {'F0.5 Score (Focus Precision)'}")
print("-" * 68)

soglie_test = np.arange(0.50, 0.81, 0.03)
miglior_f05 = -1
soglia_ottimale = 0.65

for soglia in soglie_test:
    pred = (migliori_prob_oos >= soglia).astype(int)
    n_segnali = pred.sum()
    
    if n_segnali == 0:
        continue
        
    prec = precision_score(y_oos_reale, pred, zero_division=0)
    rec = recall_score(y_oos_reale, pred, zero_division=0)
    
    if (0.25 * prec + rec) > 0:
        f05 = (1.25 * prec * rec) / (0.25 * prec + rec)
    else:
        f05 = 0.0
        
    nota = ""
    if n_segnali >= MIN_SEGNALI_RICHIESTI and f05 > miglior_f05:
        miglior_f05 = f05
        soglia_ottimale = soglia
        nota = " <-- MIGLIORE"
        
    print(f"{soglia:>6.0%}   | {n_segnali:<8} | {prec:>10.2%}   | {rec:>6.2%}   | {f05:.4f}{nota}")

print(f"\nSoglia ottimale selezionata: {soglia_ottimale:.0%}")

# --- 5. REPORT FINALE CON PARAMETRI E SOGLIA OTTIMIZZATI ---
previsioni_ottime = (migliori_prob_oos >= soglia_ottimale).astype(int)
tn, fp, fn, tp = confusion_matrix(y_oos_reale, previsioni_ottime, labels=(0, 1)).ravel()

print(f"\n=== RISULTATI OUT-OF-SAMPLE OTTIMIZZATI (Soglia {soglia_ottimale:.0%}) ===")
print(f"Vero NO  (Non salito e previsto NO):  {tn}")
print(f"Falso SÌ (Non salito ma previsto SÌ): {fp}  <-- Falsi allarmi")
print(f"Falso NO (Salito ma previsto NO):     {fn}  <-- Occasioni perse")
print(f"Vero SÌ  (Salito e previsto SÌ):      {tp}  <-- Rialzi indovinati")
print("\n", classification_report(y_oos_reale, previsioni_ottime, target_names=('Non Sale (0)', 'Sale >=3% (1)'), zero_division=0))

# --- 6. ADDESTRAMENTO FINALE E PREVISIONE PER OGGI ---
pesi_finali = np.linspace(0.5, 1.5, len(X))
modello_finale = RandomForestClassifier(
    n_estimators=300,
    random_state=42,
    n_jobs=-1,
    **migliori_parametri
)
modello_finale.fit(X, y, sample_weight=pesi_finali)

probabilita_oggi = modello_finale.predict_proba(ultimi_dati_oggi[features]).item(1)
data_oggi = ultimi_dati_oggi.index.item().strftime('%Y-%m-%d')
segnale_oggi = (
    f"SEGNALE POSITIVO (Supera soglia ottimale {soglia_ottimale:.0%})"
    if probabilita_oggi >= soglia_ottimale
    else f"NESSUN SEGNALE (Sotto soglia ottimale {soglia_ottimale:.0%})"
)

print(f"--- PREVISIONE OPERATIVA PER IL {data_oggi} ---")
print(f"Confidenza del modello: {probabilita_oggi:.2%}")
print(f"Esito filtro:           {segnale_oggi}")
