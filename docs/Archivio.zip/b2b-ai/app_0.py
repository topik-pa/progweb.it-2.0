import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.ensemble import RandomForestClassifier

st.set_page_config(page_title="PredictB2B - MVP Churn & Riordini", layout="wide")

# --- 1. FUNZIONE PER GENERARE DATI DEMO REALISTICI ---
@st.cache_data
def genera_dati_demo():
    np.random.seed(42)
    n_clienti = 150
    records = []
    oggi = datetime.today()
    
    for c in range(1, n_clienti + 1):
        cliente_id = f"CLI_{c:03d} - Azienda {c} Srl"
        # Frequenza media di ordine (tra 7 e 45 giorni)
        freq_media = np.random.randint(7, 45)
        importo_medio = np.random.uniform(250, 3500)
        
        # Alcuni clienti smettono di ordinare negli ultimi mesi (Churn)
        is_churning = np.random.choice([True, False], p=[0.25, 0.75])
        stop_date = oggi - timedelta(days=np.random.randint(60, 150)) if is_churning else oggi
        
        curr_date = oggi - timedelta(days=730) # 2 anni di storico
        while curr_date < stop_date:
            records.append({
                "id_cliente": cliente_id,
                "data_ordine": curr_date.strftime("%Y-%m-%d"),
                "importo": round(np.random.normal(importo_medio, importo_medio * 0.2), 2)
            })
            curr_date += timedelta(days=int(np.random.normal(freq_media, freq_media * 0.2)))
            
    return pd.DataFrame(records)

# --- 2. FEATURE ENGINEERING (TRASFORMA FATTURE IN INDICATORI ML) ---
def prepara_features(df):
    df['data_ordine'] = pd.to_datetime(df['data_ordine'])
    data_rif = df['data_ordine'].max()
    
    # Calcolo intervalli tra ordini per ogni cliente
    df = df.sort_values(['id_cliente', 'data_ordine'])
    df['giorni_tra_ordini'] = df.groupby('id_cliente')['data_ordine'].diff().dt.days
    
    features = df.groupby('id_cliente').agg(
        ultimo_ordine=('data_ordine', 'max'),
        totale_ordini=('data_ordine', 'count'),
        fatturato_totale=('importo', 'sum'),
        scontrino_medio=('importo', 'mean'),
        frequenza_media_gg=('giorni_tra_ordini', 'mean'),
        std_frequenza_gg=('giorni_tra_ordini', 'std')
    ).reset_index()
    
    features['giorni_da_ultimo_ordine'] = (data_rif - features['ultimo_ordine']).dt.days
    features['frequenza_media_gg'] = features['frequenza_media_gg'].fillna(30)
    features['std_frequenza_gg'] = features['std_frequenza_gg'].fillna(5)
    
    # Rapporto di ritardo: > 1 significa che il cliente è in ritardo rispetto alla sua media
    features['rapporto_ritardo'] = features['giorni_da_ultimo_ordine'] / features['frequenza_media_gg']
    
    # Definizione target storico (simulata per l'addestramento: ritardo > 2.2x la propria media)
    features['target_abbandono'] = (features['rapporto_ritardo'] > 2.2).astype(int)
    return features

# --- 3. ADDESTRAMENTO MODELLO PREDICTIVE ---
def esegui_predizione(features):
    X = features[['totale_ordini', 'scontrino_medio', 'frequenza_media_gg', 'giorni_da_ultimo_ordine', 'rapporto_ritardo']]
    y = features['target_abbandono']
    
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X, y)
    
    # Calcola la probabilità di rischio per ogni cliente
    features['probabilita_rischio'] = np.round(model.predict_proba(X)[:, 1] * 100, 1)
    features['valore_a_rischio_annuo'] = np.round((365 / features['frequenza_media_gg']) * features['scontrino_medio'], 2)
    return features.sort_values(by=['probabilita_rischio', 'valore_a_rischio_annuo'], ascending=False)

# --- 4. INTERFACCIA WEB (STREAMLIT) ---
st.title("📊 PredictB2B — Radar Abbandono Clienti & Riordini")
st.markdown("Carica lo storico ordini/fatture (CSV) per individuare i clienti abituali che stanno per abbandonarti.")

uploaded_file = st.sidebar.file_uploader("Carica il CSV del gestionale", type=["csv"])
usa_demo = st.sidebar.checkbox("Usa dati aziendali simulati (Demo)", value=True)

if uploaded_file is not None:
    df_raw = pd.read_csv(uploaded_file)
elif usa_demo:
    df_raw = genera_dati_demo()
else:
    st.warning("Carica un file CSV o attiva i dati simulati nella barra laterale.")
    st.stop()

# Elaborazione
df_feat = prepara_features(df_raw)
risultati = esegui_predizione(df_feat)

# KPI Principali
col1, col2, col3 = st.columns(3)
clienti_critici = risultati[risultati['probabilita_rischio'] > 60]
fatturato_rischio = clienti_critici['valore_a_rischio_annuo'].sum()

col1.metric("Clienti Analizzati", len(risultati))
col2.metric("Clienti ad Alto Rischio (>60%)", len(clienti_critici))
col3.metric("Fatturato Annuo a Rischio", f"€ {fatturato_rischio:,.2f}")

st.subheader("🚨 Lista Prioritaria per la Rete Vendita")
st.markdown("Questi clienti stanno ordinando molto meno rispetto alla loro **abitudine storica individuale**.")

tabella_output = clienti_critici[[
    'id_cliente', 'probabilita_rischio', 'valore_a_rischio_annuo', 
    'giorni_da_ultimo_ordine', 'frequenza_media_gg', 'scontrino_medio'
]].rename(columns={
    'id_cliente': 'Cliente',
    'probabilita_rischio': 'Rischio Abbandono (%)',
    'valore_a_rischio_annuo': 'Valore Annuo Stimato (€)',
    'giorni_da_ultimo_ordine': 'Giorni dall\'ultimo ordine',
    'frequenza_media_gg': 'Frequenza Storica (gg)',
    'scontrino_medio': 'Ordine Medio (€)'
})

st.dataframe(tabella_output, use_container_width=True)
